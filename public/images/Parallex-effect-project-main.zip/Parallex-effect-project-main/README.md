# Parallex-effect-project
A Fantastic Experience Today, we learned about PARALLAX WEBSITE, which was very well explained and taught to us by Love Babbar. I've learned 3-D Transformation, 3-D Preserve, and a lot more.

So let's talk about what a Parallax Website is ,Parallax scrolling is a web design technique in which the background of a website moves slower than the foreground. As visitors scroll down the site, this creates a 3D effect, adding depth and creating a more immersive browsing experience. The concept of parallax is based on optical illusion.


#mernstackdeveloper #html #css #reactjs #nodejs #javascriptdeveloper #codehelp #lovebabbar
